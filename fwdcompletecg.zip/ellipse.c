/*
 *ellispse.c
 *NAME: Ashley Tuscano
 *CLASS:SE COMPS
 *ROLL NO: 7674
 *SERIAL NO: 61
 *DATE: 6/3/17
 */
#include<stdio.h>
#include<stdlib.h>
#include<gl.h>
#include<glu.h>
#include<glut.h>
#include<math.h>
void ellipse(float xc,float yc,float rx,float ry)
{
	float x=0,y=ry;
	glBegin(GL_POINTS);
	glVertex2f(x,y);
	glVertex2f(x+xc,y+yc);
	glVertex2f(-x+xc,y+yc);
	glVertex2f(x+xc,-y+yc);
	glVertex2f(-x+xc,-y+yc);
	p=ry*ry-rx*rx*ry+0.25*rx*rx;
	while(2*ry*ry*x<2*rx*rx*y)
	{
		if(p<0)
		{
			p=p+2*ry*x*ry+ry*ry;
			x=x+1;
		}
		else
		{
			p=p+2*(x*ry*ry)+ry*ry-2*rx*rx*y;
			x=x+1;
			y--;
		}
		glVertex2f(x+xc,y+yc);
		glVertex2f(-x+xc,y+yc);
		glVertex2f(x+xc,-y+yc);
		glVertex2f(-x+xc,-y+yc);
	}
	p=(x+0.5)*(x+0.5)*ry*ry+(y-1)*(y-1)*rx*rx-rx*rx*ry*ry;
	while(y>0)
	{
		if(p>0)
		{
			y--;
			p=p-2*y*rx*rx+rx*rx;
		}
		else
		{
			x++;
			y--;
			p=p-2*y*rx*rx+2*x*ry*ry+rx*rx;
		}
		glVertex2f(x+xc,y+yc);
		glVertex2f(-x+xc,y+yc);
		glVertex2f(x+xc,-y+yc);
		glVertex2f(-x+xc,-y+yc);
	}
	glEnd();
}
void disp()
{
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0,0,0);
	for(int i=0;i<10;i++)
		ellipse(96+i,96+i,40,60);
	glFlush();
}
int main(int argv,char **argc)
{
	glutInit(&argv,argc);
	glutInitWindowSize(300,300);
	glutCreateWindow("window");
	gluOrtho2D(0,300,0,300);
	glutDisplayFunc(disp);
	glutMainLoop();
	return 0;
}



