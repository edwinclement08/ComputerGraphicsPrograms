/*
 *mid-point_circle.c
 *NAME: Ashley Tuscano
 *CLASS:SE COMPS
 *ROLL NO: 7674
 *SERIAL NO: 61
 *DATE: 6/2/17
 */
#include<stdio.h>
#include<stdlib.h>
#include<gl.h>
#include<glu.h>
#include<glut.h>
#include<math.h>
void midpt_circle( )
{
	glBegin(GL_POINTS);
	float x1=100,y1=100,r=50,x=0,y=r;
	float pk;
	pk=(5/4)-r;
	glVertex2f(x,y);
	while(x<y)
	{
		if(pk<=0)
		{
			pk=pk+2*x+3;
			x=x+1;

		}
		else
		{
			pk=pk+2*x-2*y+5;
			x=x+1;
			y=y-1;
		}
		glVertex2f(x+x1,y+y1);
		glVertex2f(y+y1,x+x1);
		glVertex2f(x+x1,-y+y1);
		glVertex2f(-y+y1,x+x1);
		glVertex2f(-x+x1,-y+y1);
		glVertex2f(-y+y1,-x+x1);
		glVertex2f(-x+x1,y+y1);
		glVertex2f(y+y1,-x+x1);
	}
	glEnd();
}
void disp()
{
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0,0,0);
	midpt_circle();
	glFlush();
}
int main(int argv,char **argc)
{
	glutInit(&argv,argc);
	glutInitWindowSize(300,300);
	glutCreateWindow("window");
	gluOrtho2D(0,300,0,300);
	glutDisplayFunc(disp);
	glutMainLoop();
	return 0;
}



