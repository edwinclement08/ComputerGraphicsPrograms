/*
 * dda.c
 * NAME: Ashley Tuscano
 * CLASS:SE COMPS
 * ROLL NO: 7674
 * SERIAL NO: 61
 * DATE: 23/1/17
 */
#include<stdio.h>
#include<stdlib.h>
#include<glut.h>
#include<glu.h>
#include<gl.h>
void dda()
{
    float x1,y1,x2,y2,dx,dy,steps,i,xinc,yinc;
    printf("Enter the points\n");
    scanf("%f%f%f%f",&x1,&y1,&x2,&y2);
    dx=x2-x1;
    dy=y2-y1;
    if(abs(dx)>=abs(dy))
        steps=abs(dx);
    else
        steps=abs(dy);
    
    xinc=dx/steps;
    yinc=dy/steps;
    glBegin(GL_POINTS);
    glVertex2f(x1,y1);
    for(i=0;i<=steps;i++)
    {
        x1=x1+xinc;
        y1=y1+yinc;
        glVertex2f(x1,y1);
    }
	glEnd();
}

void disp()
{
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0,0,0);
      dda()//call your function define at beginning
	glFlush();
}
int main(int argv,char **argc)
{
	glutInit(&argv,argc);
	glutInitWindowSize(300,300);
	glutCreateWindow("window");
	gluOrtho2D(0,300,0,300);
	glutDisplayFunc(disp);
	glutMainLoop();
	return 0;
}


