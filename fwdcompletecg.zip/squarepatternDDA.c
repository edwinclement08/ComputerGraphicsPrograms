/********************************************************
 Name : Ashley Tuscano
 Rollno : 7674
 Program : To draw a pattern of squares using dda algorithm
*********************************************************/
#include<stdio.h>
#include<stdlib.h>
#include<gl.h>
#include<glu.h>
#include<glut.h>
#include<math.h>
void dda(float x1,float y1,float x2,float y2)
{   float i,dx,dy,xinc,yinc;
    int steps;
    dx=x2-x1;
    dy=y2-y1;
    if(abs(dx)>abs(dy))
        steps=abs(dx);
    else
        steps=abs(dy);
    xinc=dx/steps;
    yinc=dy/steps;
    glBegin(GL_POINTS);
    glVertex2f(x1,y1);
    for(i=0.0;i<steps;i++)
    {
        x1=x1+xinc;
        y1=y1+yinc;
        glVertex2f(x1,y1);
    }
    glEnd();
}
void squarepattern()
{
	for(i=0.0;i<5.0;i++)
    {
        dda(10.0+10*i,10.0,20.0+10*i,10.0);
        dda(20.0+10*i,10.0,20.0+10*i,20.0);
        dda(20.0+10*i,20.0,10.0+10*i,20.0);
        dda(10.0+10*i,20.0,10.0+10*i,10.0);
    }
}
void disp()
{	float i;
    glClearColor(1,1,1,1);
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0,0,0);
 	squarepattern();
    glFlush();
}//disp
int main(int argv,char **argc)
{	glutInit(&argv,argc);
    glutInitWindowSize(300,300);
    glutCreateWindow("window");
    gluOrtho2D(0,300,0,300);
    glutDisplayFunc(disp);
    glutMainLoop();
    return 0;}
