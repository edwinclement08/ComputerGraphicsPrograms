/*
 *Post Lab : DRAWING PATTERNS USING MIDPOINT CIRCLE ALGORITHM
 *NAME : Ashley Tuscano
 *ROLL NO : 7674
 */
#include<stdio.h>
#include<stdlib.h>
#include<gl.h>
#include<glu.h>
#include<glut.h>
#include<math.h>
void midpt_circle(float x1,float y1,float r)
{
	glBegin(GL_POINTS);
	float x=0,y=r;
	float pk;
	pk=(5/4)-r;
	glVertex2f(x,y);
	while(x<y)
	{
		if(pk<=0)
		{
			pk=pk+2*x+3;
			x=x+1;

		}
		else
		{
			pk=pk+2*x-2*y+5;
			x=x+1;
			y=y-1;
		}
		glVertex2f(x+x1,y+y1);
		glVertex2f(y+x1,x+y1);
		glVertex2f(x+x1,-y+y1);
		glVertex2f(-y+x1,x+y1);
		glVertex2f(-x+x1,-y+y1);
		glVertex2f(-y+x1,-x+y1);
		glVertex2f(-x+x1,y+y1);
		glVertex2f(y+x1,-x+y1);
	}
	//glBegin(GL_POINTS);
		//glVertex2f(x,y); //Sample for ploting pixel at (x,y)
	glEnd();
}
void circle_pattern()
{
	int i,a=100,b=100;
	for(i=0;i<=50;i++)
	{
		midpt_circle(a,b,50);
		a+=1;
		b+=1;
	}
}
void disp()
{
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0,0,8);
	circle_pattern();//call your function define at beginning
	//for example WriteFunctionName();
glFlush();
}//disp
int main(int argv,char **argc)
{
	glutInit(&argv,argc);
	glutInitWindowSize(300,300);
	glutCreateWindow("window");
	gluOrtho2D(0,300,0,300);
	glutDisplayFunc(disp);
	glutMainLoop();
	return 0;
}