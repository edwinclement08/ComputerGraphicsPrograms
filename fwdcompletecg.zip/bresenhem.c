/*****************************************************
 NAME : Ashley Tuscano
 ROLL NO : 7674
 TITLE : TO IMPLEMENT BRESENHAM LINE ALGORITHM
 ****************************************************/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<openGL/gl.h>
#include<openGL/glu.h>
#include<GLUT/glut.h>
void bresenham()
{
	float x1,y1,x2,y2,dx,dy,x,y,xEnd,p,twoDy,twoDyDx;
	printf("Enter value of x1: ");
	scanf("%f",&x1);
	printf("\n");
	printf("Enter value of y1: ");
	scanf("%f",&y1);
	printf("\n");
	printf("Enter value of x2: ");
	scanf("%f",&x2);
	printf("\n");
	printf("Enter value of y2: ");
	scanf("%f",&y2);
	printf("\n");
	dx=x2-x1;
	dy=y2-y1;
	p=2*dy-dx;
	twoDy=2*dy;
	twoDyDx=2*(dy-dx);
	if(x1>x2)
	{
		x=x2;
		y=y2;
		xEnd=x1;

	}
	else
	{
		x=x1;
		y=y1;
		xEnd=x2;
	}
	glBegin(GL_POINTS);
	printf("x = %f\ty = %f\n",x,y);
	glVertex2f(x,y);
	while(x<xEnd)
	{
		x++;
		if(p<0)
		{
			p+=twoDy;
			printf("x = %f\ty = %f\n",x,y);
			glVertex2f(x,y);
		}
		else
		{
			y++;
			p+=twoDyDx;
			printf("x = %f\ty = %f\n",x,y);
			glVertex2f(x,y);
		}
	}
	glEnd();
}
void disp()
{
	glClearColor(1,1,1,1);   //Gives color to the background
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0,0,0);        //color of the line
	bresenham();
	glFlush();           //prints all points together
}
int main(int argv,char **argc)
{
	glutInit(&argv,argc);
	glutInitWindowSize(300,300);
	glutCreateWindow("BRESENHAM");
	gluOrtho2D(0,300,0,300);
	glutDisplayFunc(disp);
	glutMainLoop();
	return 0;
}

